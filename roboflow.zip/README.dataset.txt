# datasets > 2025-01-30 10:08pm
https://universe.roboflow.com/hi-84op6/datasets-mfndt

Provided by a Roboflow user
License: CC BY 4.0

